package com.pizza.service;

import com.pizza.model.CartItem;
import com.pizza.model.FoodItem;
import com.pizza.model.User;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {
    private static final String CART_SESSION_KEY = "CART";

    public void addItem(HttpSession session, FoodItem foodItem) {
        List<CartItem> cartItems = getCartItems(session);
        CartItem cartItem = getCartItem(cartItems, foodItem.getId());
        if (cartItem == null) {
            cartItem = new CartItem();
            cartItem.setFoodItem(foodItem);
            cartItem.setQuantity(1);
            cartItems.add(cartItem);
        } else {
            cartItem.setQuantity(cartItem.getQuantity() + 1);
        }
        session.setAttribute(CART_SESSION_KEY, cartItems);
    }

    public void addItem(User user, FoodItem foodItem) {
        List<CartItem> cartItems = user.getCartItems();
        CartItem cartItem = getCartItem(cartItems, foodItem.getId());
        if (cartItem == null) {
            cartItem = new CartItem();
            cartItem.setFoodItem(foodItem);
            cartItem.setQuantity(1);
            cartItem.setUser(user);
            cartItems.add(cartItem);
        } else {
            cartItem.setQuantity(cartItem.getQuantity() + 1);
        }
    }

    public void modifyItemQuantity(HttpSession session, Long cartItemId, int quantity) {
        List<CartItem> cartItems = getCartItems(session);
        CartItem cartItem = getCartItem(cartItems, cartItemId);
        if (cartItem != null) {
            if (quantity <= 0) {
                cartItems.remove(cartItem);
            } else {
                cartItem.setQuantity(quantity);
            }
        }
        session.setAttribute(CART_SESSION_KEY, cartItems);
    }

    public void modifyItemQuantity(User user, Long cartItemId, int quantity) {
        List<CartItem> cartItems = user.getCartItems();
        CartItem cartItem = getCartItem(cartItems, cartItemId);
        if (cartItem != null) {
            if (quantity <= 0) {
                cartItems.remove(cartItem);
            } else {
                cartItem.setQuantity(quantity);
            }
        }
    }

    public void removeItem(HttpSession session, Long cartItemId) {
        List<CartItem> cartItems = getCartItems(session);
        CartItem cartItem = getCartItem(cartItems, cartItemId);
        if (cartItem != null) {
            cartItems.remove(cartItem);
        }
        session.setAttribute(CART_SESSION_KEY, cartItems);
    }

    public void removeItem(User user, Long cartItemId) {
        List<CartItem> cartItems = user.getCartItems();
        CartItem cartItem = getCartItem(cartItems, cartItemId);
        if (cartItem != null) {
            cartItems.remove(cartItem);
        }
    }

    public List<CartItem> getCartItems(HttpSession session) {
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute(CART_SESSION_KEY);
        if (cartItems == null) {
            cartItems = new ArrayList<>();
            session.setAttribute(CART_SESSION_KEY, cartItems);
        }
        return cartItems;
    }

    public List<CartItem> getCartItems(User user) {
        return user.getCartItems();
    }

    private CartItem getCartItem(List<CartItem> cartItems, Long foodItemId) {
        for (CartItem cartItem : cartItems) {
            if (cartItem.getFoodItem().getId().equals(foodItemId)) {
return cartItem;
}
}
return null;
}

public double getTotalPrice(HttpSession session) {
    double totalPrice = 0;
    List<CartItem> cartItems = getCartItems(session);
    for (CartItem cartItem : cartItems) {
        totalPrice += cartItem.getSubtotal();
    }
    return totalPrice;
}

public double getTotalPrice(User user) {
    double totalPrice = 0;
    List<CartItem> cartItems = user.getCartItems();
    for (CartItem cartItem : cartItems) {
        totalPrice += cartItem.getSubtotal();
    }
    return totalPrice;
}

public int getCartSize(HttpSession session) {
    List<CartItem> cartItems = getCartItems(session);
    int cartSize = 0;
    for (CartItem cartItem : cartItems) {
        cartSize += cartItem.getQuantity();
    }
    return cartSize;
}

public int getCartSize(User user) {
    List<CartItem> cartItems = user.getCartItems();
    int cartSize = 0;
    for (CartItem cartItem : cartItems) {
        cartSize += cartItem.getQuantity();
    }
    return cartSize;
}
}
