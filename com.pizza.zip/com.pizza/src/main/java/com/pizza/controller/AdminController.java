
package com.pizza.controller;

import com.pizza.model.FoodItem;
import com.pizza.model.Order;
import com.pizza.model.PizzaStore;
import com.pizza.repository.FoodItemRepository;
import com.pizza.repository.OrderRepository;
import com.pizza.repository.PizzaStoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private PizzaStoreRepository pizzaStoreRepository;

    @Autowired
    private FoodItemRepository foodItemRepository;

    @Autowired
    private OrderRepository orderRepository;

    @GetMapping("/adminhome")
    public String showAdminHome(Model model) {
        return "adminhome";
    }

    @GetMapping("/addpizzastore")
    public String showAddPizzaStoreForm(Model model) {
        model.addAttribute("pizzaStore", new PizzaStore());
        return "addpizzastore";
    }

    @PostMapping("/addpizzastore")
    public String processAddPizzaStoreForm(@ModelAttribute PizzaStore pizzaStore) {
    	System.out.println(pizzaStore);
        pizzaStoreRepository.save(pizzaStore);
        return "redirect:/admin/adminhome";
    }

    @GetMapping("/addfooditem")
    public String showAddFoodItemForm(Model model) {
        model.addAttribute("foodItem", new FoodItem());
        model.addAttribute("pizzaStores", pizzaStoreRepository.findAll());
        return "addfooditem";
    }

    @PostMapping("/addfooditem")
    public String processAddFoodItemForm(@ModelAttribute FoodItem foodItem) {
    	System.out.println(foodItem);
        foodItemRepository.save(foodItem);
        return "redirect:/admin/adminhome";
    }

    @GetMapping("/deletefooditem")
    public String showDeleteFoodItemForm(Model model) {
        model.addAttribute("foodItems", foodItemRepository.findAll());
        return "deletefooditem";
    }

    @PostMapping("/deletefooditem")
    public String processDeleteFoodItemForm(@RequestParam Long foodItemId) {
        foodItemRepository.deleteById(foodItemId);
        return "redirect:/admin/adminhome";
    }

    @GetMapping("/viewfooditem")
    public String showViewFoodItemForm(Model model) {
        List<FoodItem> foodItems = foodItemRepository.findAll();
        model.addAttribute("foodItems", foodItems);
        return "viewfooditem";
    }

    @GetMapping("/modifyfooditem")
    public String showModifyFoodItemForm(Model model) {
        List<FoodItem> foodItems = foodItemRepository.findAll();
        model.addAttribute("foodItems", foodItems);
        model.addAttribute("pizzaStores", pizzaStoreRepository.findAll());
        return "modifyfooditem";
    }

    @PostMapping("/modifyfooditem")
    public String processModifyFoodItemForm(@RequestParam Long id, @ModelAttribute FoodItem foodItem) {
        FoodItem existingFoodItem = foodItemRepository.findById(id).orElse(null);
        if (existingFoodItem != null) {
            existingFoodItem.setName(foodItem.getName());
            existingFoodItem.setDescription(foodItem.getDescription());
            existingFoodItem.setPrice(foodItem.getPrice());
            existingFoodItem.setImageUrl(foodItem.getImageUrl());
            foodItemRepository.save(existingFoodItem);
        }
        return "redirect:/admin/viewfooditem";
    }



    @GetMapping("/changeorderstatus")
    public String showChangeOrderStatusForm(Model model) {
        List<Order> orders = orderRepository.findAll();
        model.addAttribute("orders", orders);
        return "changeorderstatus";
    }

	@PostMapping("/changeorderstatus")
	public String processChangeOrderStatusForm(@RequestParam Long orderId, @RequestParam String orderStatus) {
		Order order = orderRepository.findById(orderId).orElse(null);
		order.setOrderStatus(orderStatus);
		orderRepository.save(order);
		return "redirect:/admin/adminhome";
	}
}
